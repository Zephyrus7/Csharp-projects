﻿using System;

namespace Assignment2
{
    public class Program
    {
        #region Hidden

        public static void Main(string[] args)
        {
            string number;
            do
            {
                Console.Write("Enter the number (1-7) for the question to run or 0 to exit: ");
                number = Console.ReadLine();
                ShowTitle(number);

                switch (number)
                {
                    case "1":
                        Question1();
                        break;
                    case "2":
                        Question2();
                        break;
                    case "3":
                        Question3();
                        break;
                    case "4":
                        Question4();
                        break;
                    case "5":
                        Question5();
                        break;
                    case "6":
                        Question6();
                        break;
                    case "7":
                        Question7();
                        break;
                }
            } while (number != "0");
        }

        public static void ShowTitle(string number)
        {
            Console.Clear();
            Console.WriteLine("Question {0}", number);
            Console.WriteLine("------------");
            Console.WriteLine();
        }
        
        #endregion

        /// <summary>
        /// Write code to prompt the user to enter their first name, middle initial
        /// and last name. Then read their input and display the user's name three 
        /// times using the following three formats:
        ///     first last
        ///     first middle last
        ///     last, first middle
        /// </summary>
        public static void Question1()
        {

        }

        /// <summary>
        /// Write code to prompt the user for two integers. Then read their input and
        /// display the sum and the difference of the two integers.
        /// </summary>
        public static void Question2()
        {

        }

        /// <summary>
        /// Write code to calculate the area of a circle. The user will enter the radius
        /// of the circle and the program will calculate and display the area. 
        /// You must accept decimal places as input.
        /// Formula: area = 3.14 * radius * radius
        /// </summary>
        public static void Question3()
        {

        }

        /// <summary>
        /// Write code to prompt the user to enter a single character. Then read their 
        /// input and display the following message: You entered <char>
        /// For this question, you must use a variable of type char.
        /// </summary>
        public static void Question4()
        {

        }

        /// <summary>
        /// Write code to ask the user a simple true or false question and then read
        /// their answer. The code should then display the message: Your answer was <bool>
        /// For this question, you must use a variable of type boolean.
        /// </summary>
        public static void Question5()
        {

        }

        /// <summary>
        /// Write code to prompt the user to enter how many siblings they have.
        /// Then read their input and display a message saying: I also have <int> siblings
        /// </summary>
        public static void Question6()
        {

        }

        /// <summary>
        /// Adult tickets cost $3.75 and child tickets cost $2.25. Write code to prompt 
        /// the user for the number of adult tickets and the number of child tickets 
        /// that they want. Then display the total cost.
        /// </summary>
        public static void Question7()
        {

        }
    }
}
